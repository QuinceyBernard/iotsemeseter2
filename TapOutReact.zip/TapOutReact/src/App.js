//APP JS ACTS AS THE BRIDGE BETWEEN INDEX AND REACT

import React, { Component } from 'react';
import PubNubReact from 'pubnub-react';
import Chart from './components/chart'
import './App.css';
import './components/c3.css'
import Header from './components/header/header';
import Pubnub from './components/pubnub';
import logo from './logo.svg'
var totalFlow;



//components



class App extends Component {
  constructor(){
    super();
    //pubnub for chart data
    this.pubnub = new PubNubReact({
        publishKey: 'pub-c-a219e012-6c9b-41c0-9f7a-553973bdcbcb',
        subscribeKey: 'sub-c-cb4e4ad2-498a-11e9-bc3e-aabf89950afa'

    });


    this.datepub = [[]];
    this.pubnub.history(

        {
      channel : 'Water',
      count : 10
      },
      (function (status, response) {

        for(let i = 0; i < response.messages.length; i++) {
          this.datepub[0][i] = response.messages[i]['entry']['eon']['total']; //reading response messages into array
        }

        this.datepub[0].unshift('Total (ml)'); // adding label to start of array 0
        this.setState({datepub:this.datepub}); //update datepub
      }).bind(this)						//binding to present execution context
    );


  this.state = {
    chartType: 'spline',
    datepub: this.datepub,
    pubnub: this.pubnub,
    channel: 'Water'
  };



  this.pubnub.init(this);
}//constructor

componentWillMount(){

  this.pubnub.subscribe({
      channels: ['Water'],
      withPresence: true
  });


//pushes last 7 values and displays total water flow
  this.pubnub.getMessage('Water', (msg) => {



      this.datepub[0].push(msg.message.eon.total);
      if(this.datepub[0].length > 7){
        this.datepub[0].splice(1,1);
        // this.datepub[0].shift();
      }
      this.setState({datepub:this.datepub}); //update datepub



  },10);

}



_setBarChart = () => {
    console.log("Bar");
    this.setState({ chartType: 'bar' });
}

_setLineChart = () => {
    console.log("Line");
    this.setState({ chartType: 'spline' })
}







  render() {
    return (


      <div className="App">

        <Header />
        <Pubnub />
        <br></br>
        <div className="history">
        <Chart ident="chart1" datepub = {this.state.datepub} pubnub={this.state.pubnub} channel={this.state.channel} chartType={this.state.chartType}/>

        </div>

     </div>
    );
  }
}

export default App;
