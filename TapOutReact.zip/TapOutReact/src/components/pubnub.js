import React, { Component } from 'react';
import PubNubReact from 'pubnub-react';
let currentFlow;


//pubnub for live water flow
export default class Pubnub extends Component {

    constructor(props) {

        super(props);
        this.pubnub = new PubNubReact({
            publishKey: 'pub-c-a219e012-6c9b-41c0-9f7a-553973bdcbcb',
            subscribeKey: 'sub-c-cb4e4ad2-498a-11e9-bc3e-aabf89950afa'

        });
        this.pubnub.init(this);

      }

    componentWillMount() {
        //subscription
        this.pubnub.subscribe({
            channels: ['Water'],
            withPresence: true
        });

        //live flow message
        this.pubnub.getMessage('Water', (msg) => {

            currentFlow = msg.message.eon.flow;


        },10);

        this.pubnub.getStatus((st) => {

        });
    }


    render() {
        /*const messages = this.pubnub.getMessage('Water');*/
        return (
            <div className="container-fluid">
            <div className="messagebox">
            <br></br>
            <br></br>
            <br></br>
            <h2>
            Water Flow <b>: {currentFlow} ml/s</b>
            </h2>
            </div>
            <br></br>


            </div>

        );
    }
}
