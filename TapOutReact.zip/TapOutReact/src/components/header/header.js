import React, { Component } from 'react';
import {

} from 'react-router-dom';
// import { slide as Menu } from 'react-burger-menu';
import logo from './tap.svg';



//header
class Header extends Component {
  render() {
    return (
      <header>
      <div className="topBar">
           <div className="logo">
           <h1> TapOut </h1>
           </div>

      </div>

      </header>

    );
  }
}

export default Header;
